/* ESP32 WiFi Scanning example */
#include <Arduino.h>

static const int LED_PIN = 2;
bool led = false;

unsigned long last=0;
unsigned long lastPrint = 0;
//tarefa 1- piscar
void blink_led ()
{
  unsigned long now = millis();
  if(now - last >= 500 ){

    if (led == false)
      {
      digitalWrite(LED_PIN, led);
      led=true;
      }
      else{
        digitalWrite(LED_PIN, led);
      led=false;
      }
  Serial.printf("[millis] periodo = %lu ms\n", (now-last));
  last=now;
  }
}
 
 //tarefa 2
void process_anything ()
{
  unsigned long temp0= micros();
  for(volatile long i=0; i<50; i++){}
  unsigned long temp1 = micros() - temp0;
  if(millis() - lastPrint >=2000)
  {
    lastPrint=millis();
    Serial.printf("[micros] periodo = %lu us\n", temp1);
  }
}

void setup() {
  Serial.begin(115200);
  Serial.println("Hello, ESP32!");
  pinMode(LED_PIN, OUTPUT);
}

void loop() {
blink_led();
process_anything();
}